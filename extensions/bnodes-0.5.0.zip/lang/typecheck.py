"""AST -> ir.Graph, checked against a Schema.

Every error is collected with its position, so one pass reports them all.
"""

import difflib
from dataclasses import dataclass

from . import ast, colors, ir, sugar
from .errors import BnError, Diagnostic
from .parser import parse
from .schema import (DATABLOCKS, FIELD_TYPES, IMPLICIT, ITEM_NODES, ITEM_TYPES, NO_DEFAULT, NO_VALUE, RANGED, STRICT,
                     TREE_KINDS, TYPES, Socket, can_link, key)

GROUP_NODES = {
    "geometry": "GeometryNodeGroup",
    "shader": "ShaderNodeGroup",
    "compositor": "CompositorNodeGroup",
}


@dataclass
class Out:
    """A node's output. `chosen` is None until `.socket` picks one: the first is used."""
    node: str
    outputs: list
    chosen: Socket | None
    label: str

    @property
    def socket(self):
        return self.chosen or (self.outputs[0] if self.outputs else None)


@dataclass
class Lit:
    value: object
    type: str


@dataclass
class Sym:
    """A name bound to nothing: an enum value, such as POWER or FACE."""
    name: str


def check(file, schema, filename="<text>", load=None):
    """Checked graphs, callees before callers, those of the modules first. Raises BnError.

    `load(name, source)` gives a module's (text, filename) for a `use`, or raises
    LookupError with the reason; without it, a `use` is an error.
    """
    return Modules(schema, load).check(file, filename).order


@dataclass
class Unit:
    """A checked file: its graphs by key, and every graph it needs, callees first."""
    graphs: dict  # key -> ast.Graph
    order: list   # of ir.Graph, those of its own modules included


class Modules:
    """Checks a file and the modules it uses, each module once."""

    def __init__(self, schema, load):
        self.schema = schema
        self.load = load
        self.done = {}  # (name, source) -> Unit
        self.units = {}  # id of a Use -> the Unit it loaded

    def check(self, file, filename, ident=None, stack=()):
        diags = []
        imported = self.imports(file, filename, stack, diags)
        by_name = {}
        # Graphs are called by their key: "Smooth by Angle" is called as smooth_by_angle(...)
        for g in file.graphs:
            if key(g.name) in by_name:
                diags.append(Diagnostic(filename, g.line, g.col, f"graph « {key(g.name)} » défini deux fois"))
            elif key(g.name) in imported:
                diags.append(Diagnostic(filename, g.line, g.col, f"« {key(g.name)} » est défini ici et importé de "
                                                                 f"{imported[key(g.name)][1].name}"))
            by_name[key(g.name)] = g
        callable_ = {k: g for k, (g, _u) in imported.items()} | by_name
        order = self.needed(file.uses, imported)
        # A module that failed would make every call to it an unknown node too
        unsure = any(id(u) not in self.units for u in file.uses)
        own = check_graphs(file.graphs, by_name, callable_, self.schema, filename, diags, unsure)
        if diags:
            raise BnError(diags)
        for g in own:
            g.module = ident
        seen = set()
        return Unit(by_name, [g for g in order + own if not (g.name in seen or seen.add(g.name))])

    def imports(self, file, filename, stack, diags):
        """{key: (ast.Graph, its Use)} of the graphs the uses bring."""
        imported = {}
        names = set()
        for u in file.uses:
            def error(message):
                diags.append(Diagnostic(filename, u.line, u.col, message))
            if u.name in names:
                error(f"module « {u.name} » importé deux fois : un seul use par module")
                continue
            names.add(u.name)
            unit = self.unit(u, stack, error)
            if unit is None:
                continue
            self.units[id(u)] = unit
            wanted = u.names if u.names is not None else list(unit.graphs)
            for k in wanted:
                if k not in unit.graphs:
                    error(f"« {k} » n'est pas dans le module {u.name} ; graphs : {short_list(sorted(unit.graphs))}")
                elif k in imported and imported[k][1].name != u.name:
                    error(f"« {k} » est dans {imported[k][1].name} et dans {u.name} : "
                          f"choisir avec use {u.name} (…)")
                else:
                    imported[k] = (unit.graphs[k], u)
        return imported

    def unit(self, u, stack, error):
        ident = (u.name, u.source)
        if ident in stack:
            error("import circulaire : " + " → ".join(n for n, _s in stack + (ident,)))
            return None
        if ident in self.done:
            return self.done[ident]
        if self.load is None:
            error("use : aucun module à charger ici")
            return None
        try:
            text, filename = self.load(u.name, u.source)
        except LookupError as e:
            error(f"module « {u.name} » : {e.args[0] if e.args else e}")
            return None
        try:
            unit = self.check(parse(text, filename), filename, ident, stack + (ident,))
        except BnError as e:
            first, n = e.diagnostics[0], len(e.diagnostics)
            error(f"module « {u.name} » : {first}" + (f" (+{n - 1} erreur(s))" if n > 1 else ""))
            return None
        self.done[ident] = unit
        return unit

    def needed(self, uses, imported):
        """The modules' graphs to build: a whole module, or the names listed and what they call."""
        out = []
        for u in uses:
            unit = self.units.get(id(u))
            if unit is None:
                continue
            if u.names is None:
                out += unit.order
                continue
            by_ir = {g.name: g for g in unit.order}
            keep = set()
            todo = [unit.graphs[k].name for k in u.names if k in unit.graphs]
            while todo:
                name = todo.pop()
                if name in keep or name not in by_ir:
                    continue
                keep.add(name)
                todo += [n.group for n in by_ir[name].nodes if n.group]
            out += [g for g in unit.order if g.name in keep]
        return out


def check_graphs(graphs, by_name, callable_, schema, filename, diags, unsure=False):
    """The file's own graphs, checked, callees before callers."""
    checked, calls = {}, {}
    for g in graphs:
        c = GraphChecker(g, callable_, schema, filename, diags)
        c.unsure = unsure
        checked[key(g.name)] = c.run()
        calls[key(g.name)] = c.calls

    order = []
    state = {}

    def visit(name, via):
        if state.get(name) == "done":
            return
        if state.get(name) == "open":
            g = by_name[via]
            diags.append(Diagnostic(filename, g.line, g.col, f"appel récursif : « {via} » rappelle « {name} »"))
            return
        state[name] = "open"
        for callee in calls.get(name, ()):
            visit(callee, name)
        state[name] = "done"
        if checked.get(name):
            order.append(checked[name])

    for g in graphs:
        visit(key(g.name), key(g.name))
    return order


class GraphChecker:
    def __init__(self, graph, graphs, schema, filename, diags):
        self.g = graph
        self.graphs = graphs
        self.schema = schema
        self.filename = filename
        self.diags = diags
        self.nodes = []
        self.env = {}
        self.calls = set()
        self.separated = {}  # (node id, output identifier) -> SeparateXYZ node id, for p.x
        self.frames = []
        self.returned = None
        self.zone = None  # inside a repeat body: (output node, its item sockets, input node, its outputs)
        self.given = set()  # states the current repeat body returns
        self.frame_now = None
        self.unsure = False  # a module failed to load: an unknown call may be one of its graphs

    def error(self, at, message):
        self.diags.append(Diagnostic(self.filename, at.line, at.col, message))

    def run(self):
        g = self.g
        if g.kind == "pixel":
            self.error(g, "pixel est un type d'arbre de Blade ; dans Blender : geometry, shader, compositor")
            return None
        if g.kind not in TREE_KINDS:
            self.error(g, f"type d'arbre « {g.kind} » inconnu ; types : {', '.join(TREE_KINDS)}")
            return None

        ok = True
        for p in g.params + g.outputs:
            if p.type not in TYPES:
                self.error(p, f"type « {p.type} » inconnu ; types : {', '.join(TYPES)}")
                ok = False
        if not ok:
            return None

        defaults = self.defaults()
        gin = ir.Node(ir.GROUP_INPUT, "NodeGroupInput", n_outputs=len(g.params), line=g.line, col=g.col)
        gout = ir.Node(ir.GROUP_OUTPUT, "NodeGroupOutput", n_inputs=len(g.outputs), line=g.line, col=g.col)
        self.nodes += [gin, gout]
        for p in g.params:
            if key(p.name) in self.env:
                self.error(p, f"paramètre « {key(p.name)} » défini deux fois")
            sock = Socket(p.name, p.name, p.type)
            self.env[key(p.name)] = Out(ir.GROUP_INPUT, [sock], sock, key(p.name))

        self.statements(g.body, gout, None)
        if not self.returned:
            self.error(g, f"return manquant dans « {g.name} »")

        graph = ir.Graph(g.kind, g.name, [(p.name, p.type) for p in g.params],
                         [(o.name, o.type) for o in g.outputs], self.nodes, g.line, g.col, self.frames, defaults)
        graph.options = self.options()
        graph.description = g.description
        return graph

    # Interface

    def defaults(self):
        """{input name: {"value", "min", "max", "implicit"}} from `name: Type = default in lo..hi`."""
        for o in self.g.outputs:
            if o.default is not None or o.range is not None:
                self.error(o, f"la sortie « {o.name} » n'a ni valeur par défaut ni bornes")
        out = {}
        for p in self.g.params:
            spec = {}
            d = p.default
            if isinstance(d, ast.Call) and d.name in IMPLICIT:
                mode, wanted = IMPLICIT[d.name]
                if d.args:
                    self.error(d, f"{d.name}() en valeur par défaut ne prend pas d'argument")
                elif p.type != wanted:
                    self.error(d, f"{d.name}() ne sert de valeur par défaut qu'à une entrée {wanted}")
                else:
                    spec["implicit"] = mode
            elif d is not None:
                value = self.default_value(p, d)
                if value is not None:
                    spec["value"] = value
            if p.range is not None:
                bounds = self.bounds(p)
                if bounds is not None:
                    spec.update((k, v) for k, v in zip(("min", "max"), bounds) if v is not None)
            if spec:
                out[p.name] = spec
        return out

    def options(self):
        """{(side, name): {property: value}} from `x: Float(subtype: FACTOR, …)`.

        The property names are Blender's, checked by the builder; here only their values are."""
        out = {}
        for side, params in (("INPUT", self.g.params), ("OUTPUT", self.g.outputs)):
            for p in params:
                found = {}
                for a in p.options:
                    if a.name in WRITTEN_ELSEWHERE:
                        self.error(a, f"{a.name} s'écrit {WRITTEN_ELSEWHERE[a.name]}")
                        continue
                    if a.name in found:
                        self.error(a, f"option « {a.name} » donnée deux fois")
                        continue
                    v = a.value
                    if isinstance(v, ast.Ref):
                        found[a.name] = v.name
                    elif isinstance(v, (ast.Number, ast.String, ast.Bool, ast.Neg)) and \
                            isinstance(self.eval(v), Lit):
                        found[a.name] = self.eval(v).value
                    else:
                        self.error(a, f"option « {a.name} » : un nombre, true/false, un texte ou une valeur comme FACTOR")
                if found:
                    out[(side, p.name)] = found
        return out

    def default_value(self, p, d):
        t = p.type
        if t in NO_DEFAULT:
            self.error(d, f"une entrée {t} n'a pas de valeur par défaut")
            return None
        if t == "Menu" and isinstance(d, (ast.Ref, ast.String)):
            return d.name if isinstance(d, ast.Ref) else d.value
        if not isinstance(d, (ast.Number, ast.String, ast.Bool, ast.Tuple, ast.Neg)):
            self.error(d, f"valeur par défaut de « {p.name} » : un nombre, un tuple, true/false, un texte"
                          f" ou {', '.join(n + '()' for n in IMPLICIT)}")
            return None
        v = self.eval(d)
        if v is None:
            return None
        if t == "Float" and v.type in ("Int", "Float"):
            return float(v.value)
        if t in ("Int", "Bool") and v.type == t:
            return v.value
        # A Vector of 2 or 4 numbers sets the socket's dimensions
        if t == "Vector" and isinstance(v.value, tuple) or t == "Rotation" and v.type == "Vector" and len(v.value) == 3:
            return v.value
        if t == "Color" and v.type in ("Vector", "Color") and len(v.value) in (3, 4):
            return v.value
        if (t == "String" or t in DATABLOCKS) and v.type == "String":
            return v.value
        self.error(d, f"valeur par défaut de type {v.type} pour une entrée {t}")
        return None

    def bounds(self, p):
        at = p.range[0] or p.range[1]
        if p.type not in RANGED:
            self.error(at, f"une entrée {p.type} n'a pas de bornes ; bornes pour : {', '.join(sorted(RANGED))}")
            return None
        values = []
        for b in p.range:
            if b is None:
                values.append(None)
                continue
            v = self.eval(b) if isinstance(b, (ast.Number, ast.Neg)) else None
            if not (isinstance(v, Lit) and v.type in ("Int", "Float")) or p.type == "Int" and v.type != "Int":
                self.error(b, f"borne de « {p.name} » : un nombre{' entier' if p.type == 'Int' else ''}")
                return None
            values.append(v.value if p.type == "Int" else float(v.value))
        if None not in values and values[0] > values[1]:
            self.error(at, f"bornes de « {p.name} » : le min dépasse le max")
            return None
        return tuple(values)

    # Statements

    def statements(self, body, gout, frame):
        """Check a block; the nodes each statement makes go into `frame`."""
        for stmt in body:
            if self.returned and not (isinstance(stmt, ast.Frame) and not stmt.body):
                self.error(stmt, "instruction après return")
                return
            created = len(self.nodes)
            self.frame_now = frame
            if isinstance(stmt, ast.Frame):
                self.frame_stmt(stmt, gout, frame)
                continue
            if isinstance(stmt, ast.Assign):
                self.assign_stmt(stmt)
            elif self.zone is not None:
                self.zone_return(stmt)
                self.returned = stmt
                self.zone[0].frame = frame
            else:
                self.return_stmt(stmt, gout)
                self.returned = stmt
                gout.frame = frame
            for n in self.nodes[created:]:
                # A repeat body has placed its own nodes, frames included
                if n.frame is None:
                    n.frame = frame

    def frame_stmt(self, f, gout, parent):
        color = None
        if f.color is not None:
            color = colors.rgb(f.color[1:])
            if color is None:
                self.error(f, f"couleur « {f.color} » inconnue : #rrggbb, #rgb ou un nom CSS (#orange, #teal…)")
        frame = ir.Frame(f"f{len(self.frames)}", f.label, color, parent, f.line, f.col)
        self.frames.append(frame)
        self.statements(f.body, gout, frame.id)

    def assign_stmt(self, stmt):
        if stmt.name in self.env:
            self.error(stmt, f"« {stmt.name} » est déjà défini")
            return
        created = len(self.nodes)
        if isinstance(stmt.value, ast.Repeat):
            value = self.repeat(stmt.value, stmt.name)
        else:
            value = self.eval(stmt.value)
        if value is None:
            # Keep the name known, so later uses do not report it again
            self.env[stmt.name] = None
            return
        if isinstance(value, Out) and value.node in {n.id for n in self.nodes[created:]}:
            node = next(n for n in self.nodes if n.id == value.node)
            if node.name is None:
                node.name = stmt.name
        self.env[stmt.name] = value

    def return_stmt(self, stmt, gout):
        gout.line, gout.col = stmt.line, stmt.col
        outs = [Socket(o.name, o.name, o.type) for o in self.g.outputs]
        if isinstance(stmt.value, ast.Record):
            # Outputs left out stay unlinked, as Blender allows
            given = {}
            for f in stmt.value.fields:
                sock = next((s for s in outs if f.name in (s.name, key(s.name))), None)
                if sock is None:
                    self.error(f, f"« {f.name} » n'est pas une sortie ; sorties : {', '.join(s.name for s in outs)}")
                    continue
                if f.name in given:
                    self.error(f, f"sortie « {f.name} » donnée deux fois")
                    continue
                given[f.name] = f
                value = self.eval(f.value)
                if value is not None:
                    self.connect(gout, sock, value, f, "return")
            return
        if not self.g.single_output:
            self.error(stmt, f"ce graph a plusieurs sorties : return ({', '.join(s.name + ': …' for s in outs)})")
            return
        value = self.eval(stmt.value)
        if value is not None:
            self.connect(gout, outs[0], value, stmt.value, "return")

    # Repeat zones

    def repeat(self, e, name):
        """A Repeat zone: its input node takes the count and the starting states, its body
        computes the next states from the current ones, its output node gives the last."""
        rin = ir.Node(f"n{len(self.nodes)}", ir.REPEAT_INPUT, line=e.line, col=e.col)
        rout = ir.Node(f"n{len(self.nodes) + 1}", ir.REPEAT_OUTPUT, line=e.line, col=e.col)
        rin.pair = rout.id
        self.nodes += [rin, rout]
        count = self.eval(e.count)
        starts, items = [], []
        for a in e.states:
            v = self.eval(a.value)
            t = value_type(v)
            if key(a.name) in {key(n) for n, _t in items}:
                self.error(a, f"état « {a.name} » déclaré deux fois")
                continue
            if key(a.name) == "iteration":
                self.error(a, "« iteration » est le numéro du tour : choisir un autre nom d'état")
                continue
            if v is None:
                continue
            if t not in REPEAT_ITEMS:
                self.error(a, f"un état de repeat ne peut pas être de type {t}")
                continue
            items.append((a.name, t))
            starts.append((a, v))
        rin.items = rout.items = items
        states = [Socket(n, n, t) for n, t in items]
        rin_inputs = [Socket("Iterations", "Iterations", "Int")] + states
        rin_outputs = [Socket("Iteration", "Iteration", "Int")] + states
        rin.n_inputs, rin.n_outputs = len(rin_inputs), len(rin_outputs)
        rout.n_inputs = rout.n_outputs = len(states)
        if count is not None:
            self.connect(rin, rin_inputs[0], count, e.count, "repeat")
        for (a, v), sock in zip(starts, states):
            self.connect(rin, sock, v, a, "repeat")

        # The body sees the outer names, the states and `iteration`; its own names stay inside
        saved = self.env, self.returned, self.zone, self.given
        self.env = dict(self.env)
        for sock in states:
            self.env[key(sock.name)] = Out(rin.id, rin_outputs, sock, key(sock.name))
        self.env["iteration"] = Out(rin.id, rin_outputs, rin_outputs[0], "iteration")
        self.returned = None
        self.zone = (rout, states, rin, rin_outputs)
        self.given = set()
        frame = self.frame_now
        self.statements(e.body, None, frame)
        if not self.returned:
            self.error(e, f"return manquant dans le repeat de « {name} »")
        # A state the body does not return goes on unchanged
        for sock in states:
            if sock.name not in self.given:
                rout.links.append((sock.identifier, ir.Link(rin.id, sock.identifier)))
        rin.frame = rout.frame = frame
        self.env, self.returned, self.zone, self.given = saved
        self.frame_now = frame
        # With no state left, uses of the name would only repeat the error
        return Out(rout.id, states, None, name) if states else None

    def zone_return(self, stmt):
        rout, states, _rin, _outs = self.zone
        if isinstance(stmt.value, ast.Record):
            for f in stmt.value.fields:
                sock = next((s for s in states if key(f.name) == key(s.name)), None)
                if sock is None:
                    self.error(f, f"« {f.name} » n'est pas un état du repeat ; états : "
                                  f"{', '.join(s.name for s in states)}")
                    continue
                if sock.name in self.given:
                    self.error(f, f"état « {f.name} » rendu deux fois")
                    continue
                self.given.add(sock.name)
                value = self.eval(f.value)
                if value is not None:
                    self.connect(rout, sock, value, f, "repeat")
            return
        if len(states) != 1:
            self.error(stmt, f"ce repeat a plusieurs états : return ({', '.join(s.name + ': …' for s in states)})")
            return
        self.given.add(states[0].name)
        value = self.eval(stmt.value)
        if value is not None:
            self.connect(rout, states[0], value, stmt.value, "repeat")

    # Expressions

    def eval(self, e):
        if isinstance(e, ast.Number):
            return Lit(e.value, "Int" if e.is_int else "Float")
        if isinstance(e, ast.String):
            return Lit(e.value, "String")
        if isinstance(e, ast.Bool):
            return Lit(e.value, "Bool")
        if isinstance(e, ast.Tuple):
            return self.tuple(e)
        if isinstance(e, ast.Ref):
            if e.name in self.env:
                return self.env[e.name]
            return Sym(e.name)
        if isinstance(e, ast.Member):
            return self.member(e, self.eval(e.target))
        if isinstance(e, ast.Call):
            return self.call(e)
        if isinstance(e, ast.Pipe):
            left = self.eval(e.left)
            if left is None:
                return None
            if isinstance(e.call, ast.Member):
                return self.member(e.call, self.call(e.call.target, piped=left))
            return self.call(e.call, piped=left)
        if isinstance(e, ast.BinOp) and e.op == "+":
            return self.plus(e)
        if isinstance(e, ast.BinOp):
            return self.formula(e, e.op, [(self.eval(e.left), e.left), (self.eval(e.right), e.right)])
        if isinstance(e, ast.Not):
            return self.formula(e, "not", [(self.eval(e.value), e.value)])
        if isinstance(e, ast.Neg):
            v = self.eval(e.value)
            if isinstance(v, Lit) and v.type in ("Int", "Float"):
                return Lit(-v.value, v.type)
            if isinstance(v, Lit) and isinstance(v.value, tuple):
                return Lit(tuple(-x for x in v.value), v.type)
            # -x is x times -1: Math Multiply, or Vector Math Scale
            return self.formula(e, "neg", [(v, e.value), (Lit(-1.0, "Float"), e)])
        raise TypeError(e)

    def tuple(self, e):
        values = []
        for item in e.items:
            v = self.eval(item)
            if not (isinstance(v, Lit) and v.type in ("Int", "Float")):
                self.error(item, "un tuple ne contient que des nombres")
                return None
            values.append(float(v.value))
        if len(values) not in (2, 3, 4):
            self.error(e, "un tuple a 2, 3 ou 4 nombres")
            return None
        return Lit(tuple(values), "Color" if len(values) == 4 else "Vector")

    def member(self, e, target):
        if target is None:
            return None
        if isinstance(target, Sym):
            self.error(e.target, f"nom inconnu « {target.name} »")
            return None
        if not isinstance(target, Out):
            self.error(e, f"« .{e.socket} » ne s'applique qu'à un nœud")
            return None
        if e.socket in sugar.COMPONENTS and target.socket is not None and target.socket.type == "Vector" \
                and (target.chosen is not None or find_socket(target.outputs, e.socket) is None):
            return self.component(e, target)
        if target.chosen is not None:
            self.error(e, f"« {target.label} » est déjà une sortie ({target.chosen.type}) ; « .{e.socket} » n'existe pas")
            return None
        sock = find_socket(target.outputs, e.socket)
        if isinstance(sock, list):
            self.error(e, f"« {e.socket} » est ambigu ; utilisez l'identifiant : {', '.join(s.identifier for s in sock)}")
            return None
        if sock is None:
            self.error(e, f"{target.label} n'a pas de sortie « {e.socket} » ; sorties : {socket_keys(target.outputs)}")
            return None
        return Out(target.node, target.outputs, sock, f"{target.label}.{e.socket}")

    def component(self, e, target):
        """`v.x`: one Separate XYZ per vector, shared by its components."""
        src = target.socket
        spec = self.schema.node(self.g.kind, "SeparateXYZ")
        if spec is None:
            self.error(e, f"pas de SeparateXYZ dans un arbre {self.g.kind}")
            return None
        inputs, outputs = self.schema.sockets(self.g.kind, spec, {})
        memo = (target.node, src.identifier)
        if memo not in self.separated:
            node = ir.Node(f"n{len(self.nodes)}", spec.bl_idname, n_inputs=len(inputs),
                           n_outputs=len(outputs), line=e.line, col=e.col)
            self.nodes.append(node)
            self.connect(node, inputs[0], target, e, "SeparateXYZ")
            self.separated[memo] = node.id
        sock = find_socket(outputs, e.socket)
        return Out(self.separated[memo], outputs, sock, f"{target.label}.{e.socket}")

    def plus(self, e):
        """`a + b + c`: one Join Geometry for geometries, else Math or Vector Math, pair by pair.

        Joining is the same whatever the parentheses, so `a + (b + c)` is one
        Join too: the canonical graph has no Join feeding a Join of its own.
        """
        steps = []
        while isinstance(e, ast.BinOp) and e.op == "+":
            steps.append(e)
            e = e.left
        steps.reverse()
        v = self.eval(e)
        if value_type(v) == "Geometry":
            return self.join(steps[0], [(v, e)] + [(self.eval(t), t) for s in steps for t in plus_terms(s.right)])
        for s in steps:
            right = self.eval(s.right)
            if value_type(right) == "Geometry" and v is not None:
                self.error(s.left, f"« + » joint des Geometry, pas {value_type(v)}")
                return None
            v = self.formula(s, "+", [(v, s.left), (right, s.right)])
        return v

    def join(self, at, terms):
        for v, a in terms:
            if v is None:
                return None
            if isinstance(v, Sym):
                self.error(a, f"nom inconnu « {v.name} »")
                return None
            if value_type(v) != "Geometry":
                self.error(a, f"« + » joint des Geometry, pas {value_type(v)}")
                return None
        spec = self.schema.node(self.g.kind, "JoinGeometry")
        if spec is None:
            self.error(at, f"pas de JoinGeometry dans un arbre {self.g.kind}")
            return None
        inputs, outputs = self.schema.sockets(self.g.kind, spec, {})
        node = ir.Node(f"n{len(self.nodes)}", spec.bl_idname, n_inputs=len(inputs), n_outputs=len(outputs),
                       line=at.line, col=at.col)
        self.nodes.append(node)
        for v, a in terms:
            self.connect(node, inputs[0], v, a, "+")
        return Out(node.id, outputs, None, "+")

    def is_function(self, name):
        return (name in sugar.FUNCS and name not in self.graphs
                and self.schema.node(self.g.kind, name) is None)

    def formula(self, at, op, operands):
        """A Math, Vector Math or Compare node for an operator or a function, from evaluated operands."""
        for v, a in operands:
            if v is None:
                return None
            if isinstance(v, Sym):
                self.error(a, f"nom inconnu « {v.name} »")
                return None
        try:
            name, props, order = sugar.choose(op, [value_type(v) for v, _a in operands])
        except ValueError as err:
            self.error(at, str(err))
            return None
        spec = self.schema.node(self.g.kind, name)
        if spec is None:
            self.error(at, f"pas de {name} dans un arbre {self.g.kind}")
            return None
        inputs, outputs = self.schema.sockets(self.g.kind, spec, props)
        n_inputs = len(inputs)
        if name in sugar.OPERANDS:
            inputs = inputs[:sugar.OPERANDS[name]]
        if len(inputs) != len(operands):
            self.error(at, f"{op} attend {len(inputs)} argument(s), en reçoit {len(operands)}")
            return None
        node = ir.Node(f"n{len(self.nodes)}", spec.bl_idname, props=dict(props), n_inputs=n_inputs,
                       n_outputs=len(outputs), line=at.line, col=at.col)
        self.nodes.append(node)
        for sock, i in zip(inputs, order):
            v, a = operands[i]
            self.connect(node, sock, v, a, op)
        return Out(node.id, outputs, None, op)

    def call(self, c, piped=None):
        if self.is_function(c.name):
            operands = [(piped, c)] if piped is not None else []
            for a in c.args:
                if a.name is not None:
                    self.error(a, f"{c.name} ne prend pas d'argument nommé")
                    return None
                operands.append((self.eval(a.value), a.value))
            return self.formula(c, c.name, operands)

        positional = [(piped, c)] if piped is not None else []
        named = []
        failed = False
        for a in c.args:
            v = self.eval(a.value)
            failed |= v is None
            if a.name is None:
                positional.append((v, a.value))
            else:
                named.append((a.name, v, a))

        node = ir.Node(f"n{len(self.nodes)}", "", line=c.line, col=c.col)
        spec = None if c.name in self.graphs else self.schema.node(self.g.kind, c.name)
        group = self.existing_group(c) if c.name not in self.graphs and spec is None else None
        if c.name in self.graphs:
            inputs, outputs = self.group_signature(c, node)
            if inputs is None:
                return None
        elif group is not None:
            if isinstance(group, list):
                self.error(c, f"« {c.name} » désigne plusieurs groupes du fichier : "
                              f"{', '.join(g.name for g in group)}")
                return None
            node.bl_idname = GROUP_NODES[self.g.kind]
            node.group = group.name
            inputs = [Socket(n, n, t) for n, t in group.inputs]
            outputs = [Socket(n, n, t) for n, t in group.outputs]
        else:
            if spec is None:
                if self.unsure:
                    return None
                close = difflib.get_close_matches(c.name, self.schema.node_names(self.g.kind), 3)
                hint = f" ; voulez-vous dire {', '.join(close)} ?" if close else ""
                self.error(c, f"nœud « {c.name} » inconnu dans un arbre {self.g.kind}{hint}")
                return None
            node.bl_idname = spec.bl_idname
            rest = []
            for name, v, a in named:
                if name in spec.props and isinstance(v, (Lit, Sym)):
                    self.prop(node, spec.props[name], v, a)
                else:
                    rest.append((name, v, a))
            named = rest
            if spec.bl_idname in ITEM_NODES:
                inputs, outputs = self.item_sockets(c, spec, node, positional, named)
                if inputs is None:
                    return None
            else:
                inputs, outputs = self.schema.sockets(self.g.kind, spec, node.props)

        node.n_inputs, node.n_outputs = len(inputs), len(outputs)
        self.nodes.append(node)
        if failed:
            positional = [(v, a) for v, a in positional if v is not None]
            named = [(n, v, a) for n, v, a in named if v is not None]

        given = set()
        i = 0
        for v, a in positional:
            if i >= len(inputs):
                self.error(a, f"{c.name} prend {len(inputs)} entrée(s) : {socket_keys(inputs)}")
                break
            sock = inputs[i]
            self.connect(node, sock, v, a, c.name)
            given.add(sock.identifier)
            if not sock.multi_input:
                i += 1

        for name, v, a in named:
            sock = find_socket(inputs, name)
            if isinstance(sock, list):
                self.error(a, f"« {name} » est ambigu ; utilisez l'identifiant : {', '.join(s.identifier for s in sock)}")
                continue
            if sock is None:
                self.error(a, f"{c.name} n'a pas d'entrée « {name} » ; entrées : {socket_keys(inputs)}")
                continue
            if sock.identifier in given and not sock.multi_input:
                self.error(a, f"entrée « {name} » donnée deux fois")
                continue
            given.add(sock.identifier)
            self.connect(node, sock, v, a, c.name)

        return Out(node.id, outputs, None, c.name)

    def item_sockets(self, c, spec, node, positional, named):
        """(inputs, outputs) of a node whose items the call makes, which it records in node.items."""
        shape = ITEM_NODES[spec.bl_idname]
        fixed = self.schema.sockets(self.g.kind, spec, node.props)[0][:shape.inputs]
        if shape.named:
            if len(positional) > shape.inputs:
                self.error(positional[shape.inputs][1], f"{c.name} : les valeurs se donnent par nom, "
                                                        f"{c.name}(…, nom: valeur)")
                return None, None
            given = [(n, v, a) for n, v, a in named if find_socket(fixed, n) is None]
            named[:] = [(n, v, a) for n, v, a in named if find_socket(fixed, n) is not None]
        else:
            given = [(str(k), v, a) for k, (v, a) in enumerate(positional[shape.inputs:])]
            del positional[shape.inputs:]
        items, values = [], []
        for name, v, a in given:
            if key(name) in {key(n) for n, _t in items}:
                self.error(a, f"{c.name} : « {name} » donné deux fois")
                continue
            if isinstance(v, Sym) and v.name == NO_VALUE and not shape.typed:
                # An empty item: no link, its default value (an empty geometry…)
                items.append((name, None))
                continue
            if isinstance(v, Sym):
                self.error(a, f"nom inconnu « {v.name} »")
                continue
            if v is not None:
                items.append((name, value_type(v)))
                values.append((name, v, a))
        if shape.typed:
            for (name, t), (_n, _v, a) in zip(items, values):
                if t not in FIELD_TYPES:
                    self.error(a, f"{c.name} ne capture pas un {t} ; types : {', '.join(FIELD_TYPES)}")
                    return None, None
        else:
            # The items share the node's data_type: written, or the type of the first one
            chosen = node.props.get("data_type")
            typed = [t for _n, t in items if t is not None]
            t = DATA_TYPES.get(chosen) if chosen else typed[0] if typed else "Float"
            if t not in ITEM_TYPES:
                self.error(c, f"{c.name} : pas d'items de type {chosen or t}")
                return None, None
            node.props["data_type"] = ITEM_TYPES[t]
            items = [(name, t) for name, _t in items]
        node.items = items
        inputs, outputs = self.schema.sockets(self.g.kind, spec, node.props)
        sockets = [Socket(name, name, t) for name, t in items]
        if shape.named:
            named += values
        else:
            # Each value to its own item: an empty one in between is skipped by name
            named += [(name, v, a) for name, v, a in values]
        flags = [Socket(name, name, "Bool") for name, _t in items] if shape.flags else []
        return (inputs[:shape.inputs] + sockets,
                outputs[:shape.outputs] + (sockets if shape.typed else flags))

    def existing_group(self, c):
        """A node group of the file with that key, when the text does not define one."""
        groups = getattr(self.schema, "groups", None)
        return groups(self.g.kind).get(c.name) if groups else None

    def group_signature(self, c, node):
        callee = self.graphs[c.name]
        if callee.kind != self.g.kind:
            self.error(c, f"« {c.name} » est un graph {callee.kind}, pas {self.g.kind}")
            return None, None
        self.calls.add(c.name)
        node.bl_idname = GROUP_NODES[self.g.kind]
        node.group = callee.name
        return ([Socket(p.name, p.name, p.type) for p in callee.params],
                [Socket(o.name, o.name, o.type) for o in callee.outputs])

    def prop(self, node, prop, v, a):
        if prop.kind == "ENUM":
            value = v.name if isinstance(v, Sym) else v.value if v.type == "String" else None
            if value is None:
                self.error(a, f"{prop.name} attend une valeur comme {prop.items[0] if prop.items else 'MODE'}")
                return
            if prop.items and value not in prop.items:
                close = difflib.get_close_matches(value, prop.items, 1)
                hint = f" ; voulez-vous dire {close[0]} ?" if close else ""
                self.error(a, f"{prop.name}: {value} inconnu{hint} ; valeurs : {short_list(prop.items)}")
                return
        elif prop.kind == "BOOLEAN" and isinstance(v, Lit) and v.type == "Bool":
            value = v.value
        elif prop.kind == "INT" and isinstance(v, Lit) and v.type == "Int":
            value = v.value
        elif prop.kind == "FLOAT" and isinstance(v, Lit) and v.type in ("Int", "Float"):
            value = float(v.value)
        elif prop.kind == "STRING" and isinstance(v, Lit) and v.type == "String":
            value = v.value
        else:
            self.error(a, f"{prop.name} attend une valeur {prop.kind.lower()}")
            return
        node.props[prop.name] = value

    def connect(self, node, sock, v, at, label):
        """Link or set one input of `node` from a value."""
        where = f"{label}.{sock.key}" if label != "return" else f"la sortie « {sock.name} »"
        if isinstance(v, Out):
            src = v.socket
            if src is None:
                self.error(at, f"« {v.label} » n'a pas de sortie")
            elif not can_link(src.type, sock.type):
                self.error(at, f"{where} attend {sock.type}, reçoit {src.type} ({v.label})")
            else:
                node.links.append((sock.identifier, ir.Link(v.node, src.identifier)))
            return
        if sock.multi_input:
            self.error(at, f"{where} n'accepte que des liens")
            return
        if isinstance(v, Sym):
            if sock.type == "Menu":
                node.values[sock.identifier] = v.name
            else:
                self.error(at, f"nom inconnu « {v.name} »")
            return
        ok = (v.type == sock.type
              or (sock.type == "Menu" and v.type == "String")
              or (sock.type in DATABLOCKS and v.type == "String")
              or (sock.type not in STRICT and v.type not in STRICT))
        if not ok:
            self.error(at, f"{where} attend {sock.type}, reçoit {v.type}")
            return
        if sock.type == "Int" and v.type == "Float":
            # Blender would not round it: say so rather than fail at build
            self.error(at, f"{where} attend un entier : {int(v.value)} plutôt que {v.value}")
            return
        node.values[sock.identifier] = v.value


# Interface settings the text writes in their own way, not as options
WRITTEN_ELSEWHERE = {
    "name": "avant les deux-points", "socket_type": "après les deux-points : x: Float",
    "bl_socket_idname": "avec le type et subtype", "default_value": "après = : x: Float = 1.0",
    "min_value": "avec in : x: Float in 0.0..1.0", "max_value": "avec in : x: Float in 0.0..1.0",
    "default_input": "après = : p: Vector = Position()", "dimensions": "par la taille du défaut : (0.5, 0.5)",
}

# Text type -> the socket type of a Repeat zone item
REPEAT_ITEMS = {t: v for t, v in ITEM_TYPES.items() if t != "Shader"}
DATA_TYPES = {v: t for t, v in ITEM_TYPES.items()}


def plus_terms(e):
    """The terms of `a + (b + c)`, parentheses aside."""
    if isinstance(e, ast.BinOp) and e.op == "+":
        return plus_terms(e.left) + plus_terms(e.right)
    return [e]


def value_type(v):
    if isinstance(v, Out):
        return v.socket.type if v.socket else None
    if isinstance(v, Lit):
        return v.type
    return None


def find_socket(sockets, name):
    """By identifier, then UI name, then snake_case key. A list when ambiguous."""
    for attr in ("identifier", "name", "key"):
        found = [s for s in sockets if getattr(s, attr) == name]
        if len(found) == 1:
            return found[0]
        if found:
            return found
    return None


def socket_keys(sockets):
    """How to name each socket in text: its key, or its identifier when the key repeats."""
    keys = [s.key for s in sockets]
    return ", ".join(k if keys.count(k) == 1 else s.identifier for k, s in zip(keys, sockets)) or "aucune"


def short_list(items, limit=12):
    items = list(items)
    return ", ".join(items[:limit]) + (", …" if len(items) > limit else "")
