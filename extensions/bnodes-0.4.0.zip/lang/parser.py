"""Recursive descent parser.

Precedence, loosest first: `|>`, `or xor`, `and`, `not`, comparisons, `+ -`,
`* / ⋅ ×`, unary `-`, then `.socket`. Statements need no separator: an
expression ends where the next token cannot continue it.
"""

from . import ast
from .errors import BnError, Diagnostic
from .lexer import tokenize
from .sugar import COMPARE, WORDS


def parse(source, filename="<text>"):
    return Parser(tokenize(source, filename), filename).file()


class Parser:
    def __init__(self, tokens, filename):
        self.tokens = tokens
        self.filename = filename
        self.i = 0

    # Token helpers

    @property
    def tok(self):
        return self.tokens[self.i]

    def peek(self, offset=1):
        return self.tokens[min(self.i + offset, len(self.tokens) - 1)]

    def at(self, kind, text=None):
        t = self.tok
        return t.kind == kind and (text is None or t.text == text)

    def advance(self):
        t = self.tok
        self.i += 1
        return t

    def accept(self, kind, text=None):
        if self.at(kind, text):
            return self.advance()
        return None

    def expect(self, kind, text=None, what=None):
        if self.at(kind, text):
            return self.advance()
        self.fail(f"{what or text or kind} attendu, trouvé {describe(self.tok)}")

    def fail(self, message, tok=None):
        tok = tok or self.tok
        raise BnError([Diagnostic(self.filename, tok.line, tok.col, message)])

    # Grammar

    def file(self):
        f = ast.File()
        while not self.at("EOF"):
            f.graphs.append(self.graph())
        if not f.graphs:
            self.fail("fichier vide : aucun graph")
        return f

    def graph(self):
        kind = self.expect("IDENT", what="type d'arbre (geometry, shader, compositor)")
        self.expect("KEYWORD", "graph")
        name = self.accept("STRING") or self.expect("IDENT", what="nom du graph")
        self.expect("(")
        params = self.typed_list(")")
        self.expect("->")
        if self.accept("("):
            outputs, single = self.typed_list(")"), False
        else:
            t = self.expect("IDENT", what="type de retour")
            outputs, single = [ast.Param(t.text, t.text, t.line, t.col)], True
        self.expect("{")
        body = []
        while not self.at("}"):
            if self.at("EOF"):
                self.fail("« } » attendu avant la fin du fichier")
            body.append(self.statement())
        end = self.advance()
        return ast.Graph(kind.text, name.text, params, outputs, single, body, kind.line, kind.col, end.line)

    def typed_list(self, close):
        """`name: Type = default in lo..hi, ...` up to `close`, which is consumed."""
        items = []
        while not self.accept(close):
            name = self.accept("STRING") or self.expect("IDENT", what="nom")
            self.expect(":")
            t = self.expect("IDENT", what="type")
            p = ast.Param(name.text, t.text, name.line, name.col)
            if self.accept("="):
                p.default = self.unary()
            if self.at("IDENT", "in") and self.peek().kind != ":":
                # Either side may be left open: `in 0.0..`, `in ..1.0`
                self.advance()
                lo = None if self.at("..") else self.unary()
                self.expect("..", what="« .. » entre le min et le max")
                hi = self.unary() if self.tok.kind in ("NUMBER", "-") else None
                if lo is None and hi is None:
                    self.fail("bornes vides : écrire au moins le min ou le max")
                p.range = (lo, hi)
            items.append(p)
            if not self.accept(","):
                self.expect(close)
                break
        return items

    def statement(self):
        t = self.tok
        if self.at("{") or self.at("COLOR") or self.at("STRING") and self.peek().kind in ("{", "COLOR"):
            return self.frame()
        if self.accept("KEYWORD", "return"):
            if self.at("(") and (self.peek().kind == ")" or
                                 self.peek().kind in ("IDENT", "STRING") and self.peek(2).kind == ":"):
                self.advance()
                fields = self.args(named_only=True)
                return ast.Return(ast.Record(fields, t.line, t.col), t.line, t.col)
            return ast.Return(self.expr(), t.line, t.col)
        if self.at("IDENT") and self.peek().kind == "=":
            if t.text in WORDS:
                self.fail(f"« {t.text} » est réservé au produit {'scalaire' if t.text == 'dot' else 'vectoriel'} : "
                          "choisir un autre nom")
            self.advance()
            self.advance()
            value = self.repeat() if self.at("KEYWORD", "repeat") else self.expr()
            return ast.Assign(t.text, value, t.line, t.col)
        self.fail(f"instruction attendue (nom = …, return, ou un frame \"titre\" {{ … }}), trouvé {describe(t)}")

    def frame(self):
        t = self.tok
        label = self.accept("STRING")
        color = self.accept("COLOR")
        self.expect("{")
        body = []
        while not self.at("}"):
            if self.at("EOF"):
                self.fail("« } » attendu avant la fin du fichier")
            body.append(self.statement())
        end = self.advance()
        return ast.Frame(label and label.text, color and color.text, body, t.line, t.col, end.line)

    def repeat(self):
        t = self.advance()
        self.expect("(", what="« ( » après repeat")
        args = self.args()
        if not args or args[0].name is not None:
            self.fail("repeat attend d'abord le nombre de tours : repeat(10, état: départ, …)", t)
        if len(args) < 2:
            self.fail("repeat attend au moins un état : repeat(10, état: départ)", t)
        self.expect("{", what="« { » après repeat(…)")
        body = []
        while not self.at("}"):
            if self.at("EOF"):
                self.fail("« } » attendu avant la fin du fichier")
            body.append(self.statement())
        end = self.advance()
        return ast.Repeat(args[0].value, args[1:], body, t.line, t.col, end.line)

    def expr(self):
        left = self.disjunction()
        while self.at("|>"):
            op = self.advance()
            rhs = self.postfix()
            call = rhs.target if isinstance(rhs, ast.Member) else rhs
            if not isinstance(call, ast.Call):
                self.fail("un appel de nœud est attendu après |>", op)
            left = ast.Pipe(left, rhs, op.line, op.col)
        return left

    def disjunction(self):
        left = self.conjunction()
        while self.at("KEYWORD", "or") or self.at("KEYWORD", "xor"):
            op = self.advance()
            left = ast.BinOp(op.text, left, self.conjunction(), op.line, op.col)
        return left

    def conjunction(self):
        left = self.negation()
        while self.at("KEYWORD", "and"):
            op = self.advance()
            left = ast.BinOp("and", left, self.negation(), op.line, op.col)
        return left

    def negation(self):
        if self.at("KEYWORD", "not"):
            op = self.advance()
            return ast.Not(self.negation(), op.line, op.col)
        return self.comparison()

    def comparison(self):
        left = self.additive()
        if self.tok.kind in COMPARE:
            op = self.advance()
            left = ast.BinOp(op.text, left, self.additive(), op.line, op.col)
            if self.tok.kind in COMPARE:
                self.fail("une seule comparaison à la fois ; pour deux, passer par un nom")
        return left

    def additive(self):
        left = self.multiplicative()
        while self.at("+") or self.at("-"):
            op = self.advance()
            left = ast.BinOp(op.text, left, self.multiplicative(), op.line, op.col)
        return left

    def multiplicative(self):
        left = self.unary()
        # After an operand, `dot` and `cross` can only be products: they are reserved names
        while self.tok.kind in ("*", "/", "⋅", "·", "×") or \
                self.at("IDENT") and self.tok.text in WORDS and self.peek().kind != "=":
            op = self.advance()
            left = ast.BinOp(WORDS.get(op.text, op.text), left, self.unary(), op.line, op.col)
        return left

    def unary(self):
        if self.at("-"):
            op = self.advance()
            value = self.unary()
            if isinstance(value, ast.Number):
                return ast.Number(-value.value, value.is_int, op.line, op.col)
            return ast.Neg(value, op.line, op.col)
        return self.postfix()

    def postfix(self):
        node = self.primary()
        while self.at("."):
            dot = self.advance()
            if self.at("IDENT") or self.at("STRING"):
                node = ast.Member(node, self.advance().text, dot.line, dot.col)
            else:
                self.fail("nom de sortie attendu après « . »")
        return node

    def primary(self):
        t = self.tok
        if self.accept("NUMBER"):
            is_int = not any(c in t.text for c in ".eE")
            return ast.Number(int(t.text) if is_int else float(t.text), is_int, t.line, t.col)
        if self.accept("STRING"):
            return ast.String(t.text, t.line, t.col)
        if self.accept("KEYWORD", "true") or self.accept("KEYWORD", "false"):
            return ast.Bool(t.text == "true", t.line, t.col)
        if self.at("KEYWORD", "repeat"):
            self.fail("repeat s'écrit seul, en valeur d'un nom : r = repeat(10, état: départ) { … }")
        if self.at("KEYWORD", "xor") and self.peek().kind == "(":
            # The function form, kept from before `xor` was an operator
            self.advance()
            self.advance()
            return ast.Call("xor", self.args(), t.line, t.col)
        if self.accept("IDENT"):
            if self.accept("("):
                return ast.Call(t.text, self.args(), t.line, t.col)
            return ast.Ref(t.text, t.line, t.col)
        if self.accept("("):
            items = [self.expr()]
            while self.accept(","):
                if self.at(")"):
                    break
                items.append(self.expr())
            self.expect(")")
            return items[0] if len(items) == 1 else ast.Tuple(items, t.line, t.col)
        self.fail(f"expression attendue, trouvé {describe(t)}")

    def args(self, named_only=False):
        """Arguments up to `)`, which is consumed."""
        args = []
        while not self.accept(")"):
            t = self.tok
            if t.kind in ("IDENT", "STRING") and self.peek().kind == ":":
                self.advance()
                self.advance()
                args.append(ast.Arg(t.text, self.expr(), t.line, t.col))
            elif named_only:
                self.fail("champ nommé attendu (nom: valeur)")
            else:
                if any(a.name for a in args):
                    self.fail("argument positionnel après un argument nommé")
                args.append(ast.Arg(None, self.expr(), t.line, t.col))
            if not self.accept(","):
                self.expect(")")
                break
        return args


def describe(tok):
    if tok.kind == "EOF":
        return "la fin du fichier"
    return f"« {tok.text} »"
